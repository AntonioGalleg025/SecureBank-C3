#include "utils.h"

Cuenta CuentasIniciales[NUM_CUENTAS] = {
    {1, "Jude Bellingham", 2500.00, 0},
    {2, "Zinedine Zidane", 3500.00, 0},
    {3, "Vinicius Jr", 6500.00, 0},
    {4, "Cristiano Ronaldo", 1500.00, 0},
    {5, "Sergio Ramos", 1000.00, 0}
};
